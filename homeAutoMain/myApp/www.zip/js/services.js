'use strict';

angular.module('eMeMate.services', ['ngResource'])
		.constant("baseURL", "http://localhost:3000/db")
		 .factory('dbFactory', ['$resource', 'baseURL', function($resource,baseURL) {
    
    
            return $resource(baseURL);
    
        }])