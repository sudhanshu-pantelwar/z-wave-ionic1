angular.module('eMeMate.controllers', [])
// .controller('MainController', ['$scope', function($scope) {

//             $scope.room1 = "Hey from main controller";
                        
//         }])


.controller('LoginCtrl', ['$scope', function($scope) {

            $scope.room1 = "Hey from main controller";
                        
        }])

.controller('RoomsCtrl', ['$scope', 'dbFactory', function($scope, dbFactory) {

			$scope.room1=dbFactory.get('rooms');

            // $scope.room1 = "Hey from room controller";
                        
        }])

.controller('CategoryCtrl', ['$scope', function($scope) {

            $scope.room1 = "Hey from Category controller";
                        
        }])
